A collection of slides
======
...which only consists of the slides to exactly one talk.. :)

http://hkorte.github.io/slides/rsademo/
